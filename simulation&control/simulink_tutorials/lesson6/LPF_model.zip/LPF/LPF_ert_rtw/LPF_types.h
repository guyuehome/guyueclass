/*
 * File: LPF_types.h
 *
 * Code generated for Simulink model 'LPF'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Thu Feb 13 09:10:53 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->8051 Compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_LPF_types_h_
#define RTW_HEADER_LPF_types_h_
#include "rtwtypes.h"

/* Parameters (default storage) */
typedef struct P_LPF_T_ P_LPF_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_LPF_T RT_MODEL_LPF_T;

#endif                                 /* RTW_HEADER_LPF_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
